class Service {
  final String name;
  final String imageURL;
  final String action;

  Service(this.name, this.imageURL, this.action);
}
