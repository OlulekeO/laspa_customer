import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:laspa_customer/animation/FadeAnimation.dart';
import 'package:laspa_customer/modal_screens/parking_space.dart';
import 'package:laspa_customer/shared/bottomnav.dart';


class book_parkingspace extends StatefulWidget {
  const book_parkingspace({Key? key}) : super(key: key);

  @override
  _book_parkingspaceState createState() => _book_parkingspaceState();
}

class _book_parkingspaceState extends State<book_parkingspace> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Color(0xffB6B6B6),
      appBar: AppBar(
        backgroundColor: Colors.transparent,

        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(
            Icons.arrow_back_ios,
            size: 20,
            color: Colors.black,
          ),
        ),
        elevation: 0,
        actions: [
          IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.notifications_none,
              color: Colors.grey.shade700,
              size: 30,
            ),
          )
        ],

      ),

      body: SafeArea(

        child: Padding(
          padding: const EdgeInsets.all(40.0),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(10),
                  topRight: Radius.circular(10),
                  bottomLeft: Radius.circular(10),
                  bottomRight: Radius.circular(10)
              ),

              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.5),
                  spreadRadius: 5,
                  blurRadius: 7,
                  offset: Offset(0, 3), // changes position of shadow
                ),
              ],
            ),


            // we will give media query height
            // double.infinity make it big as my parent allows
            // while MediaQuery make it big as per the screen

            width: double.infinity,
            height: MediaQuery.of(context).size.height/1.8,
            padding: EdgeInsets.symmetric(horizontal: 30, vertical: 20),
            child: Column(
              // even space distribution
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Text("Parking Locations",style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
                const SizedBox(
                  height: 90,
                ),
                GestureDetector(
                  onTap:() {

                    Navigator.push(context, MaterialPageRoute(builder: (context) => parking_areas()));


                    // _onAlertWithCustomContentPressed(context);

                  },

                  child: Padding(
                    padding: const EdgeInsets.only(
                      left:0.0,
                      right:0.0,
                      top:10,
                    ),
                    child: Container(

                      height:30.0,

                      decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border(
                          bottom: BorderSide(
                              color: Colors.grey.shade300, width: 1.0),
                        ),
                      ),

                      child:Padding(
                        padding: const EdgeInsets.only(
                          left:5.0,
                          right:5.0,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,

                          children: [
                            Text('Ajah Park',  style: TextStyle(fontSize: 20,)),
                            Image.asset(
                              'assets/Arrow.png',
                              height: 20,
                            ),


                          ],



                        ),
                      ),

                    ),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),

                Padding(
                  padding: const EdgeInsets.only(
                    left:0.0,
                    right:0.0,
                    top:10,
                  ),
                  child: Container(

                    height:30.0,

                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border(
                        bottom: BorderSide(
                            color: Colors.grey.shade300, width: 1.0),
                      ),
                    ),

                    child:Padding(
                      padding: const EdgeInsets.only(
                        left:5.0,
                        right:5.0,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,

                        children: [
                          Text('Ikorodu Park',  style: TextStyle(fontSize: 20,)),
                          Image.asset(
                            'assets/Arrow.png',
                            height: 20,
                          ),


                        ],



                      ),
                    ),

                  ),
                ),
                const SizedBox(
                  height: 20,
                ),


                Padding(
                  padding: const EdgeInsets.only(
                    left:0.0,
                    right:0.0,
                    top:10,
                  ),
                  child: Container(

                    height:30.0,

                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border(
                        bottom: BorderSide(
                            color: Colors.grey.shade300, width: 1.0),
                      ),
                    ),

                    child:Padding(
                      padding: const EdgeInsets.only(
                        left:5.0,
                        right:5.0,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,

                        children: [
                          Text('Ketu Parks',  style: TextStyle(fontSize: 20,)),
                          Image.asset(
                            'assets/Arrow.png',
                            height: 20,
                          ),


                        ],



                      ),
                    ),

                  ),
                ),
                const SizedBox(
                  height: 20,
                ),

                Padding(
                  padding: const EdgeInsets.only(
                    left:0.0,
                    right:0.0,
                    top:10,
                  ),
                  child: Container(

                    height:30.0,

                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border(
                        bottom: BorderSide(
                            color: Colors.grey.shade300, width: 1.0),
                      ),
                    ),

                    child:Padding(
                      padding: const EdgeInsets.only(
                        left:5.0,
                        right:5.0,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,

                        children: [
                          Text('Vi Park',  style: TextStyle(fontSize: 20)),
                          Image.asset(
                            'assets/Arrow.png',
                            height: 20,
                          ),


                        ],



                      ),
                    ),

                  ),
                ),
                const SizedBox(
                  height: 20,
                ),





              ],
            ),
          ),
        ),

      ),
    );
  }
}
