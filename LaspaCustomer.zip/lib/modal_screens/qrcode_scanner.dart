import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:laspa_customer/shared/bottomnav.dart';


class qrcode_scanner extends StatefulWidget {
  const qrcode_scanner({Key? key}) : super(key: key);

  @override
  _qrcode_scannerState createState() => _qrcode_scannerState();
}

class _qrcode_scannerState extends State<qrcode_scanner> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Color(0xffffffff),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: Text(
          'Scan QR Code',
          style: TextStyle(color: Colors.black),
        ),
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(
            Icons.arrow_back_ios,
            size: 20,
            color: Colors.black,
          ),
        ),
        elevation: 0,
        actions: [
          IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.notifications_none,
              color: Colors.grey.shade700,
              size: 30,
            ),
          )
        ],

      ),
      body: SafeArea(
        child: Container(
          // we will give media query height
          // double.infinity make it big as my parent allows
          // while MediaQuery make it big as per the screen

          width: double.infinity,
          height: MediaQuery.of(context).size.height,
          padding: EdgeInsets.symmetric(horizontal: 30, vertical: 50),
          child: Column(
            // even space distribution
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[

              Center(
                child: Container(
                  height: MediaQuery.of(context).size.height*0.50,
                  width: double.infinity,
                  child: Image.asset(
                    "assets/scanimg.png",
                    fit: BoxFit.contain,
                    height: 200.0,
                  ),
                ),
              ),






            ],
          ),
        ),
      ),
    );
  }
}
