import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:laspa_customer/animation/FadeAnimation.dart';
import 'package:intl/intl.dart';

class customer_profile extends StatefulWidget {
  const customer_profile({Key? key}) : super(key: key);

  @override
  _customer_profileState createState() => _customer_profileState();
}

class _customer_profileState extends State<customer_profile> {
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => (true),
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Color(0xFFFFCC01),
          // title: Text(
          //   'Profile',
          //   style: TextStyle(color: Colors.black),
          // ),
          elevation: 0,
          actions: [
            IconButton(
              onPressed: () {},
              icon: Icon(
                Icons.refresh,
                color: Colors.grey.shade700,
                size: 30,
              ),
            ),
            IconButton(
              onPressed: () {},
              icon: Icon(
                Icons.notifications_none,
                color: Colors.grey.shade700,
                size: 30,
              ),
            )
          ],

          leadingWidth: 100,
          leading: Center(
              child: Text(
                'Hello Leke',
                style: TextStyle(color: Colors.black, fontSize: 16),
              )),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: <Widget>[




              FadeAnimation(
                  1.2,
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 0.0),
                    child: Container(
                      padding: EdgeInsets.all(20.0),
                      height: 170,
                      decoration: BoxDecoration(
                        color: Color(0xffFFCC01),
                        borderRadius: BorderRadius.only(

                            bottomRight:Radius.circular(10),
                            bottomLeft:Radius.circular(10),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.shade200,
                            offset: Offset(0, 4),
                            blurRadius: 10.0,
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[

                          const SizedBox(
                            height: 8,
                          ),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [

                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              SizedBox(
                                height: 10,
                              ),
                              Center(
                                child: Container(
                                  margin: const EdgeInsets.only(bottom: 5.0),
                                  height: 100,
                                  child: CircleAvatar(
                                    backgroundColor: Colors.grey,
                                    radius: 90,
                                    child: Image.asset(
                                      "assets/camera.png",
                                      height: 40,
                                    ),
                                  ),
                                ),
                              ),


                            ],
                          ),






                        ],


                      ),

                    ),
                  )),
              const SizedBox(
                height: 50,
              ),


              Padding(
                padding: const EdgeInsets.only(
                    left:0.0,
                    right:0.0,
                  top:10,
                   ),
                child: Container(

                  height:30.0,

                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border(
                      bottom: BorderSide(
                          color: Colors.grey, width: 1.0),
                    ),
                  ),

                  child:Padding(
                    padding: const EdgeInsets.only(
                      left:30.0,
                      right:30.0,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,

                      children: [
                        Text('Username',  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                        Text('Tunde Bello'),


                      ],



                    ),
                  ),

                ),
              ),
              const SizedBox(
                height: 20,
              ),
              Padding(
                padding: const EdgeInsets.only(
                  left:0.0,
                  right:0.0,
                  top:10,
                ),
                child: Container(

                  height:30.0,

                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border(
                      bottom: BorderSide(
                          color: Colors.grey, width: 1.0),
                    ),
                  ),

                  child:Padding(
                    padding: const EdgeInsets.only(
                      left:30.0,
                      right:30.0,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,

                      children: [
                        Text('Phone Number',  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                        Text('0809 9889 988'),


                      ],



                    ),
                  ),

                ),
              ),

              const SizedBox(
                height: 20,
              ),
              Padding(
                padding: const EdgeInsets.only(
                  left:0.0,
                  right:0.0,
                  top:10,
                ),
                child: Container(

                  height:30.0,

                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border(
                      bottom: BorderSide(
                          color: Colors.grey, width: 1.0),
                    ),
                  ),

                  child:Padding(
                    padding: const EdgeInsets.only(
                      left:30.0,
                      right:30.0,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,

                      children: [
                        Text('Email',  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                        Text('Tundebello@gmail.com'),


                      ],



                    ),
                  ),

                ),
              ),
              const SizedBox(
                height: 20,
              ),
              Padding(
                padding: const EdgeInsets.only(
                  left:0.0,
                  right:0.0,
                  top:10,
                ),
                child: Container(

                  height:30.0,

                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border(
                      bottom: BorderSide(
                          color: Colors.grey, width: 1.0),
                    ),
                  ),

                  child:Padding(
                    padding: const EdgeInsets.only(
                      left:30.0,
                      right:30.0,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,

                      children: [
                        Text('Plate Number',  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                        Text('AAA-56-AS'),


                      ],



                    ),
                  ),

                ),
              ),

              // Padding(
              //   padding: const EdgeInsets.all(50.0),
              //   child: MaterialButton(
              //     minWidth: double.infinity,
              //     height: 60,
              //     onPressed: () async {
              //
              //
              //
              //     },
              //     color: Color(0xffffffff),
              //     elevation: 0,
              //     shape: RoundedRectangleBorder(
              //       borderRadius: BorderRadius.circular(10),
              //     ),
              //     child: Text(
              //       "Edit Profile",
              //       style: TextStyle(
              //         fontWeight: FontWeight.w600,
              //         fontSize: 18,
              //         color: Colors.black,
              //       ),
              //     ),
              //   ),
              // ),
              const SizedBox(
                height: 40,
              ),
          OutlinedButton(
            onPressed: null,
            style: ButtonStyle(
              shape: MaterialStateProperty.all(RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0))),
            ),
            child: const Text("Edit Profile",style: TextStyle(
              fontWeight: FontWeight.w600,
              fontSize: 18,
              color: Colors.black,
            ),),
          ),


            ],

          ),
        ),
      ),
    );
  }
}
