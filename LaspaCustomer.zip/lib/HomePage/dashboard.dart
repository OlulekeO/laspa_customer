import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:laspa_customer/animation/FadeAnimation.dart';
import 'package:intl/intl.dart';
import 'package:laspa_customer/modal_screens/book_space.dart';
import 'package:laspa_customer/modal_screens/qrcode_scanner.dart';
import 'package:laspa_customer/modal_screens/verify_agent.dart';
import 'package:laspa_customer/model/service.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

String formattedDate = '';

class dashboard extends StatefulWidget {
  const dashboard({Key? key}) : super(key: key);

  @override
  _dashboardState createState() => _dashboardState();
}

class _dashboardState extends State<dashboard> {

  final _formKey = GlobalKey<FormState>();
  bool loading = false;

  String ussdbank = '';
  String ussdplatenumber = '';
  String ussdamount = '';



  _onAlertWithCustomContentPressed(context) {
    Alert(
      context: context,
      title: "Push Link",
      buttons: [],
      content: Form(
        key:  _formKey,
        child: Column(
          children: <Widget>[
            TextField(
              onChanged :(val){
                setState(() => ussdbank = val);
              },
              decoration: InputDecoration(
                // icon: Icon(Icons.account_circle),
                labelText: 'Bank',
              ),
            ),
            TextField(
              onChanged :(val){
                setState(() => ussdplatenumber = val);
              },
              decoration: InputDecoration(
                // icon: Icon(Icons.account_circle),
                labelText: 'PlateNumber',
              ),
            ),
            TextField(
              onChanged :(val){
                setState(() => ussdamount = val);
              },
              decoration: InputDecoration(
                // icon: Icon(Icons.account_circle),
                labelText: 'Amount',
              ),
            ),
            // TextField(
            //   obscureText: true,
            //   decoration: InputDecoration(
            //     // icon: Icon(Icons.lock),
            //     labelText: 'Duration',
            //   ),
            // ),
            SizedBox(
              height: 20,
            ),
            Row(
              children: <Widget>[
                Text(
                  ' *737*2*1000',
                  style: TextStyle(color: Colors.black, fontSize: 16.0),
                ),
                MaterialButton(
                  // minWidth: double.infinity,
                  height: 30,
                  color: Color(0xffffcc00),
                  onPressed: () {
                    // paywithussd();

                    // Codegenerate();
                    // String message = "Ussd code on its way";
                    // showDialog(
                    //   context: context,
                    //   builder: (BuildContext context) {
                    //     return AlertDialog(
                    //       title: new Text(GeneratedUSSDCode),
                    //       actions: <Widget>[
                    //         FlatButton(
                    //           child: new Text(GeneratedUSSDCode),
                    //           onPressed: () {
                    //             Navigator.of(context).pop();
                    //           },
                    //         ),
                    //       ],
                    //     );
                    //   },
                    // );


                  },
                  // defining the shape
                  shape: RoundedRectangleBorder(

                    // side: BorderSide(
                    //     color: Colors.black
                    // ),
                      borderRadius: BorderRadius.circular(50)),
                  child: Text(
                    "PushLink",
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 18,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    ).show();
  }


  List<Service> services = [
    Service('Pay with Qr',
        'Iconmetro-qrcode.png','_onAlertWithCustomContentPressed(context)'),
    Service('parking space',
        'Iconawesome-road.png','_onAlertWithCustomContentPressed'),
    Service('Add Hour',
        'Iconmaterial-add-alarm.png','_onAlertWithCustomContentPressed'),
    Service('Top up',
        'Iconmetro-qrcode.png','_onAlertWithCustomContentPressed'),
    Service('Push link',
        'Iconmetro-qrcode.png','_onAlertWithCustomContentPressed'),
    Service('Agent verification',
        'Iconmetro-qrcode.png','_onAlertWithCustomContentPressed'),
  ];
  List<dynamic> workers = [
    ['Alfredo Schafer', 'Plumber', 'https://images.unsplash.com/photo-1506803682981-6e718a9dd3ee?ixlib=rb-0.3.5&q=80&fm=jpg&crop=faces&fit=crop&h=200&w=200&s=c3a31eeb7efb4d533647e3cad1de9257', 4.8],
    ['Michelle Baldwin', 'Cleaner', 'https://uifaces.co/our-content/donated/oLkb60i_.jpg', 4.6],
    ['Brenon Kalu', 'Driver', 'https://uifaces.co/our-content/donated/VUMBKh1U.jpg', 4.4]
  ];

  @override
  Widget build(BuildContext context) {
    DateTime now = DateTime.now();
    String formattedDate = DateFormat('kk:mm:ss: EEE d MMM').format(now);

    return WillPopScope(
      onWillPop: () async => (true),
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          title: Text(
            'Dashboard',
            style: TextStyle(color: Colors.black),
          ),
          elevation: 0,
          actions: [
            IconButton(
              onPressed: () {},
              icon: Icon(
                Icons.notifications_none,
                color: Colors.grey.shade700,
                size: 30,
              ),
            )
          ],
          leadingWidth: 100,
          leading: Center(
              child: Text(
                'Hello Leke',
                style: TextStyle(color: Colors.black, fontSize: 16),
              )),
        ),
        body: SingleChildScrollView(
          child: Column(
              children: <Widget>[
                FadeAnimation(
                    1.2,
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20.0),
                      child: Container(
                        padding: EdgeInsets.all(20.0),
                        height: 170,
                        decoration: BoxDecoration(
                          color: Color(0xffFFCC01),
                          borderRadius: BorderRadius.circular(20.0),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.shade200,
                              offset: Offset(0, 4),
                              blurRadius: 10.0,
                            ),
                          ],
                        ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[

                      const SizedBox(
                        height: 8,
                      ),
                      const Text(
                        'Your Balance',
                        textAlign: TextAlign.left,
                      ),

                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text('6,000',
                              style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold)),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          Padding(
                            padding: EdgeInsets.all(3.0),
                            child: Image.asset(
                              'assets/LASPAo.png',
                              height: 50,
                            ),
                          ),
                        ],
                      ),


                      Text(formattedDate,
                          style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.bold)),



                    ],


                  ),
                      ),
                    )),


                SizedBox(height: 20,),
                // Container(
                //   padding: EdgeInsets.symmetric(
                //       horizontal: 20, vertical: 10),
                //   height: 120,
                //   child: ListView.builder(
                //       scrollDirection: Axis.horizontal,
                //       itemCount: services.length,
                //       itemBuilder:
                //           (BuildContext context, int index) {
                //         return FadeAnimation(
                //             (1.0 + index) / 4,
                //             serviceContainer(
                //                 services[index].imageURL,
                //                 services[index].name,
                //                 index));
                //       }),
                // ),

                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Padding(
                    padding: const EdgeInsets.all(30.0),
                    child: Row(

                      children: [

                        GestureDetector(


                          child: Container(

                            margin: EdgeInsets.only(right: 20),
                            padding: EdgeInsets.symmetric(
                                horizontal: 20, vertical: 10),

                            decoration: BoxDecoration(
                              color: Colors.white,
                              border: Border.all(
                                color: Colors.grey.shade200,
                                width: 2.0,
                              ),
                              borderRadius: BorderRadius.circular(10.0),
                            ),




                            child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Text(
                                    'Pay with Qr',
                                    style: TextStyle(fontSize: 15),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Image.asset("assets/Qr.png", height: 45),
                                ]),
                          ),
                          onTap:() {

                            Navigator.push(context, MaterialPageRoute(builder: (context) => qrcode_scanner()));


                            // _onAlertWithCustomContentPressed(context);

                          },
                        ),

                        GestureDetector(

                          child: Container(

                            margin: EdgeInsets.only(right: 20),
                            padding: EdgeInsets.symmetric(
                                horizontal: 20, vertical: 10),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              border: Border.all(
                                color: Colors.grey.shade200,
                                width: 2.0,
                              ),
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Text(
                                    'Book space',
                                    style: TextStyle(fontSize: 15),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Image.asset("assets/bookspace.png", height: 45),
                                ]),
                          ),
                          onTap:() {

                            Navigator.push(context, MaterialPageRoute(builder: (context) => book_parkingspace()));


                            // _onAlertWithCustomContentPressed(context);

                          },
                        ),
                        Container(
                          margin: EdgeInsets.only(right: 20),
                          padding: EdgeInsets.symmetric(
                              horizontal: 20, vertical: 10),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            border: Border.all(
                              color: Colors.grey.shade200,
                              width: 2.0,
                            ),
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Text(
                                  'Add Hour',
                                  style: TextStyle(fontSize: 15),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Image.asset("assets/Add.png", height: 45),
                              ]),
                        ),

                        GestureDetector(
                          child: Container(
                            margin: EdgeInsets.only(right: 20),
                            padding: EdgeInsets.symmetric(
                                horizontal: 20, vertical: 10),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              border: Border.all(
                                color: Colors.grey.shade200,
                                width: 2.0,
                              ),
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Text(
                                    'Verify agent',
                                    style: TextStyle(fontSize: 15),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Image.asset("assets/Verification.png", height: 45),
                                ]),
                          ),

                          onTap:() {

                            Navigator.push(context, MaterialPageRoute(builder: (context) => agent_verification()));


                            // _onAlertWithCustomContentPressed(context);

                          },
                        ),

                      ],


                    ),
                  ),
                ),


                // Padding(
                //   padding: const EdgeInsets.only(right:8.0),
                //   child: Container(
                //     height:50,
                //     decoration: BoxDecoration(
                //       color: Colors.white,
                //       border: Border.all(
                //         color: Colors.grey.shade200,
                //         width: 2.0,
                //       ),
                //       borderRadius: BorderRadius.circular(7.0),
                //     ),
                //     child: Padding(
                //       padding: const EdgeInsets.all(5.0),
                //       child: Row(
                //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //         children: [
                //           Image.asset(
                //             'assets/airtime.png',
                //             height: 30,
                //           ),
                //           Text('Buy Airtime'),
                //         ],
                //
                //
                //
                //       ),
                //     ),
                //
                //   ),
                // ),



                FadeAnimation(1.3, Padding(
                  padding: EdgeInsets.only(left: 20.0, right: 10.0,top:10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: const [
                      Text('Recent Transactions', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
                      // TextButton(
                      //     onPressed: () {},
                      //     child: Text('View all',)
                      // )
                    ],
                  ),
                )),
                AspectRatio(
                  aspectRatio: 4.0,
                  child: Padding(
                    padding: const EdgeInsets.only(top:15.0,bottom:20.0,left:20.0,right:20.0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(
                          color: Colors.grey.shade200,
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(7.0),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[

                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children:<Widget> [
                                ClipRRect(
                                    borderRadius: BorderRadius.circular(5.0),
                                    child: Image.asset('assets/Iconionic-md-cash.png', height: 20,)
                                ),
                                SizedBox(width: 20,),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text('Marina Park', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
                                    SizedBox(height: 5),
                                    Text('5:00pm', style: TextStyle(fontSize: 15),)
                                  ],
                                ),
                                Spacer(),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text('N 400'.toString(), style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
                                    SizedBox(height: 5,),
                                  ],
                                )
                              ],



                            ),


                          ],



                        ),
                      ),


                    ),
                  ),
                ),
                FadeAnimation(1.3, Padding(
                  padding: EdgeInsets.only(left: 20.0, right: 10.0,top:10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: const [
                      Text('Other Services', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
                      // TextButton(
                      //     onPressed: () {},
                      //     child: Text('View all',)
                      // )
                    ],
                  ),
                )),
                Padding(
             padding: const EdgeInsets.all(20.0),
             child: Container(

                   decoration: BoxDecoration(
                     color: Colors.white,

                     borderRadius: BorderRadius.circular(7.0),
                   ),

child:Row(
  mainAxisAlignment: MainAxisAlignment.spaceBetween,
  children: [

   Expanded(
     child: Padding(
       padding: const EdgeInsets.only(right:8.0),
       child: Container(
         height:50,
         decoration: BoxDecoration(
           color: Colors.white,
           border: Border.all(
             color: Colors.grey.shade200,
             width: 2.0,
           ),
           borderRadius: BorderRadius.circular(7.0),
         ),
         child: Padding(
           padding: const EdgeInsets.all(5.0),
           child: Row(
             mainAxisAlignment: MainAxisAlignment.spaceBetween,
             children: [
               Image.asset(
                 'assets/airtime.png',
                 height: 30,
               ),
               Text('Buy Airtime'),
             ],



           ),
         ),

       ),
     ),
   ),
    Expanded(
      child: Container(
        height:50,
        width:50,
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(
            color: Colors.grey.shade200,
            width: 2.0,
          ),
          borderRadius: BorderRadius.circular(7.0),
        ),

        child: Padding(
          padding: const EdgeInsets.all(5.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Image.asset(
                'assets/electricity.png',
                height: 30,
              ),
              Text('Electricity Bill'),
            ],



          ),
        ),


      ),
    ),

  ],


),

                 ),
                 // Container()





           ),
                Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Container(

                    decoration: BoxDecoration(
                      color: Colors.white,

                      borderRadius: BorderRadius.circular(7.0),
                    ),

                    child:Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [

                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(right:8.0),
                            child: Container(
                              height:50,
                              width:50,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                border: Border.all(
                                  color: Colors.grey.shade200,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(7.0),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Image.asset(
                                      'assets/data.png',
                                      height: 30,
                                    ),
                                    Text('Buy Data'),
                                  ],



                                ),
                              ),

                            ),
                          ),
                        ),
                        Expanded(
                          child: Container(
                            height:50,
                            width:50,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              border: Border.all(
                                color: Colors.grey.shade200,
                                width: 2.0,
                              ),
                              borderRadius: BorderRadius.circular(7.0),
                            ),

                            child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Image.asset(
                                    'assets/cable.png',
                                    height: 30,
                                  ),
                                  Text('Buy Cable'),
                                ],



                              ),
                            ),


                          ),
                        ),

                      ],


                    ),

                  ),
                  // Container()





                ),
              ],

          ),
        ),
      ),
    );
  }
}

serviceContainer(String image,String name, int index) {
  return GestureDetector(
    child: Container(
      margin: EdgeInsets.only(right: 20),
      padding: EdgeInsets.all(10.0),
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        border: Border.all(
          color: Colors.blue.withOpacity(0),
          width: 2.0,
        ),
        borderRadius: BorderRadius.circular(20.0),
      ),
      child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              name,
              style: TextStyle(fontSize: 15),
            ),
            SizedBox(
              height: 10,
            ),
            Image.asset("assets/"+image, height: 45),
          ]),
    ),
  );
}
workerContainer(String name, String job, String image, double rating) {
  return GestureDetector(
    child: AspectRatio(
      aspectRatio: 3.5,
      child: Container(
        margin: EdgeInsets.only(right: 20),
        padding: EdgeInsets.symmetric(vertical: 15.0, horizontal: 15.0),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(
            color: Colors.grey.shade200,
            width: 2.0,
          ),
          borderRadius: BorderRadius.circular(20.0),
        ),
        child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              ClipRRect(
                  borderRadius: BorderRadius.circular(15.0),
                  child: Image.network(image)
              ),
              SizedBox(width: 20,),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(name, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
                  SizedBox(height: 5,),
                  Text(job, style: TextStyle(fontSize: 15),)
                ],
              ),
              Spacer(),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(rating.toString(), style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
                  SizedBox(height: 5,),
                ],
              )
            ]
        ),
      ),
    ),
  );
}

parkingHistory(){


}
