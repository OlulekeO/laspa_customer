import 'package:http/http.dart' as http;
import 'package:http/http.dart' show get;
import 'dart:async';
import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:laspa_customer/modal_screens/parking_space.dart';
import 'package:laspa_customer/modal_screens/parking_area.dart';
import 'package:shared_preferences/shared_preferences.dart';



late final List<Parking> parking;

late String agentCode;



class Parking {
  final String ParkingID;
  final String ContactID;
  final String Amount;
  final String PlateNumber;
  final String ParkingTime;
  final String ParkingHour;
  final String Parkingstatus;
  final String ParkingAreaID;
  final String ParkingSpotID;
  final String ParkingAreaName;



  Parking({
    required this.ParkingID,
    required this.ContactID,
    required this.Amount,
    required this.PlateNumber,
    required this.ParkingTime,
    required this.ParkingHour,
    required this.Parkingstatus,
    required this.ParkingAreaID,
    required this.ParkingSpotID,
    required this.ParkingAreaName,


  });

  factory Parking.fromJson(Map<String, dynamic> singleUser) {
    return Parking(

      ParkingID: singleUser["ParkingID"],
      ContactID: singleUser["ContactID"],
      Amount: singleUser["Amount"],
      PlateNumber: singleUser["PlateNumber"],
      ParkingTime: singleUser["ParkingTime"],
      ParkingHour: singleUser["ParkingHour"],
      Parkingstatus: singleUser["Parkingstatus"],
      ParkingAreaID: singleUser["ParkingAreaID"],
      ParkingSpotID: singleUser["ParkingSpotID"],
      ParkingAreaName: singleUser["ParkingAreaName"],

    );




  }


}



Widget build(context) {
  return ListView.builder(
    itemCount: parking.length,
    itemBuilder: (context, int currentIndex) {
      return createUserView(parking[currentIndex], context);
    },
  );
}



class customerParkingTransactionsAll extends StatefulWidget {


  final List<Parking> parking;

  customerParkingTransactionsAll(this.parking);

  @override
  _customerParkingTransactionsAllState createState() => _customerParkingTransactionsAllState();
}

class _customerParkingTransactionsAllState extends State<customerParkingTransactionsAll> {


  void initial() async{
    var localStorage = await SharedPreferences.getInstance();
    setState((){
      agentCode = localStorage.getString('agentCode');
    });
  }
  @override

  Future getEmail()async{
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    setState(() {
      agentCode = localStorage.getString('agentCode');
    });
  }
  @override
  void initState() {
    super.initState();
    getEmail();
    //getRequest();
  }



  Widget build(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      itemCount: widget.parking.length,
      itemBuilder: (context, int currentIndex) {
        return createUserView(widget.parking[currentIndex], context);
      },
    );
  }


}


Widget createUserView(Parking parking, BuildContext context) {
  return ListTile(

    title: Column(


      children: <Widget> [


        AspectRatio(
          aspectRatio: 4.0,
          child: Padding(
            padding: const EdgeInsets.only(top:5.0,bottom:0.0,left:10.0,right:10.0),
            child: Container(
              constraints: BoxConstraints(
                maxHeight: double.infinity,
              ),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(
                  color: Colors.grey.shade200,
                  width: 2.0,
                ),
                borderRadius: BorderRadius.circular(7.0),
              ),
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[

                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children:<Widget> [
                        ClipRRect(
                            borderRadius: BorderRadius.circular(5.0),
                            child: Image.asset('assets/Iconionic-md-cash.png', height: 20,)
                        ),
                        SizedBox(width: 20,),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(parking.ParkingAreaName, style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),),
                            SizedBox(height: 3),
                            Text(parking.PlateNumber, style: TextStyle(fontSize: 15),),
                            Text(parking.ParkingTime, style: TextStyle(fontSize: 14),)
                          ],
                        ),
                        Spacer(),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text('₦ ' + parking.Amount.toString(), style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),),
                            SizedBox(height: 5,),
                          ],
                        )
                      ],



                    ),


                  ],



                ),
              ),


            ),
          ),
        ),


      ],



    ),



  );

}
// class parkingArea extends StatefulWidget {
//   final String value;
//
//
//
//
//
//
//   parkingArea({Key? key, required this.value}) : super(key: key);
//
//   @override
//   _parkingAreaState createState() => _parkingAreaState();
// }
//
// class _parkingAreaState extends State<parkingArea> {
//
//
//   SharedPreferences preferences = await SharedPreferences.getInstance();
//   setState(() {
//   password = preferences.getString('password');
//   agentCode = preferences.getString('agentCode');
//   customerEmail = preferences.getString('email');
//   customerPhone = preferences.getString('phone');
//   });
// //  print('${widget.value.ParkingAreaID}'),
//   String test = 'yea';
//
//
//   @override
//
//
//   Widget build(BuildContext context) {
//     return Container(
//
//
//       child: Text(test),
//
//     );
//   }
// }
